# Handoff: cc-hub-mobile — Session Monitor (Utilitarian direction)

## Overview
`cc-hub-mobile` is a mobile app for monitoring and controlling Claude Code coding-agent
sessions running across projects on a machine, reached over a LAN relay. This handoff
covers the **Utilitarian** visual direction (referred to as **1c** in the design review):
a dense, data-first, high-contrast UI built for scanning many sessions and their event
logs at a glance.

Four screens are covered:
1. **Sessions** — list of all agent sessions with live status.
2. **Session Detail** — chronological event log for one session, with a prompt composer.
3. **Chat** — conversational Q&A about your sessions.
4. **Knowledge Base (KB)** — searchable notes/docs across projects.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show
the intended look and behavior. They are **not production code to copy directly**. The task
is to **recreate these designs in the target codebase's environment** (React Native / Flutter /
native Android — the original screenshots were an Android Material app) using that stack's
established components and patterns. If no environment exists yet, pick the most appropriate
mobile framework and implement the designs there. Treat the HTML/CSS values below as the
source of truth for spacing, color, and type — not the DOM structure.

The prototype is built as **one reusable phone component** (`AppPhone.dc.html`) that takes a
`variant` prop (`terminal` | `clean` | `util`). **This handoff is the `util` variant.** The
parent file (`Session Monitor Redesign.dc.html`) mounts all three side by side for comparison;
only the `util` tokens matter here.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interactions are all
specified. Recreate the UI pixel-accurately using the codebase's component library. Exact hex
values, font sizes, and paddings are given below for both **dark** (default) and **light** themes.

---

## Design Tokens (Utilitarian variant)

Themeable values are CSS custom properties set on the app root and referenced everywhere via
`var(--x)`. Implement as a theme object with a dark/light switch.

### Structural (theme-independent)
| Token | Value |
|---|---|
| Base font family | `IBM Plex Sans`, system-ui fallback |
| Mono font family | `IBM Plex Mono` (paths, timestamps, raw JSON, counters) |
| Corner radius (cards/inputs) | `4px` |
| Pill/chip radius | `3px` |
| FAB radius | `6px` |
| Send-button radius | `6px` |
| List rows | full-bleed, **no gap**, separated by a 1px bottom border (`--border`) |
| Session status treatment | **3px vertical color bar** on the row's left edge + tiny uppercase colored label |
| Row initials/avatars | none |
| Micro-labels (status, meta) | **UPPERCASE**, letter-spacing `0.05em`–`0.08em` |

### Colors — Dark (default)
| Token | Hex | Use |
|---|---|---|
| `--bg` | `#0b0d10` | screen background |
| `--surface` | `#14181d` | cards, inputs, nav bar |
| `--surface2` | `#1b2027` | chips, tag backgrounds |
| `--border` | `#232a33` | dividers, outlines |
| `--text` | `#eef2f6` | primary text |
| `--dim` | `#8a95a2` | secondary text |
| `--faint` | `#586470` | tertiary / timestamps |
| `--accent` | `#2f8fff` | primary action (electric blue), FAB, send, active nav |
| `--accent-ink` | `#04121f` | text/icon on accent fills |
| `--st-idle` | `#f0b429` | status: idle (amber) |
| `--st-ended` | `#ff5c72` | status: ended (red) |
| `--st-running` | `#23c98a` | status: running (green) |
| `--st-warn` | `#f0b429` | limit/notification warning |

### Colors — Light
| Token | Hex |
|---|---|
| `--bg` | `#eaeef3` |
| `--surface` | `#ffffff` |
| `--surface2` | `#e4e9f0` |
| `--border` | `#d0d8e2` |
| `--text` | `#0f151b` |
| `--dim` | `#5b6572` |
| `--faint` | `#95a0ac` |
| `--accent` | `#1667e0` |
| `--accent-ink` | `#ffffff` |
| `--st-idle` | `#b7791f` |
| `--st-ended` | `#e0384f` |
| `--st-running` | `#12996b` |
| `--st-warn` | `#b7791f` |

Derived fills:
- Limit banner background = `--st-warn` @ 16% alpha; border = `--st-warn` @ 34% alpha.
- Status pill tint (not used in util, used in other variants) = status color @ ~15% alpha.

### Typography scale (px)
| Role | Size / weight | Font | Notes |
|---|---|---|---|
| Screen title (cc_hub, "Chat", "Knowledge Base") | 19 / 700 | Sans | letter-spacing −0.01em |
| Detail title (session name) | 16 / 700 | Sans | ellipsis truncation |
| Session name (row) | 14 / 600 | Sans | ellipsis |
| Session path | 10.5 / 400 | **Mono** | `--dim`, ellipsis |
| Status label | 9.5 / 700 | Sans | UPPERCASE, letter-spacing 0.08em, colored |
| Timestamp ("3m ago") | 10 / 400 | **Mono** | `--faint` |
| Event type label | 13 / 700 | Sans | colored by tone (see below) |
| Event main text | 12 / 400 | Sans | line-height 1.4, in a `--surface` box, ellipsis one line |
| Event raw JSON | 9.5 / 400 | **Mono** | `--faint`, ellipsis one line |
| Chat bubble | 12.5 / 400 | Sans | line-height 1.45 |
| KB title | 13.5 / 600 | Sans | |
| KB snippet | 11.5 / 400 | Sans | `--dim`, one line ellipsis |
| KB tag chip | 9 / 600 | **Mono** | UPPERCASE, letter-spacing 0.06em |
| Char counter (0/8000) | 9.5 / 400 | **Mono** | `--faint`, right-aligned |
| Bottom-nav label | 10 / 600 | Sans | |
| Status bar clock | 11 / 600 | **Mono** | |

### Spacing
- Screen horizontal padding: **16px** (14px on chat/KB list, 12px on detail header/footer).
- Session row padding: **11px 16px**.
- Card/input padding: 9–11px vertical, 12–13px horizontal.
- Event timeline: 14px rail column, 11px gap to content, 14px bottom gap per event.
- Bottom nav item padding: `9px 0 11px`.

---

## Device frame
Prototype screen canvas is **300 × 648 px** (portrait phone) inside a bezel. In the real app
this is the full device viewport. A top status bar (clock left; signal bars + theme toggle
right) sits above every screen. A notch pill is decorative.

## Screens / Views

### 1. Sessions
- **Purpose:** see every agent session and its live status; open one; start a new session.
- **Header:** title `cc_hub` (19/700). Right cluster: a **LAN** pill (1px `--border` border,
  radius 3px, mono uppercase, green dot with glow + "LAN") and a vertical 3-dot overflow `⋮`.
- **Limit banner** (below header): full-width row, radius 4px, background `--st-warn`@16%,
  border `--st-warn`@34%. Left: "Limit: unknown" (12px, `--st-warn`). Right: "OK" (11/700,
  `--accent`, tappable).
- **List:** full-bleed rows, no gap, 1px `--border` bottom divider. Each row:
  - `position:relative` with a **3px left color bar** = the session's status color.
  - Left block: session **name** (14/600, ellipsis) over **path** (10.5 mono `--dim`, ellipsis).
    Paths use Windows backslashes, e.g. `F:\rts\cc\taskmaster`.
  - Right block (right-aligned, stacked): status label (9.5/700 UPPERCASE, colored) then
    timestamp (10 mono `--faint`, "3m ago").
  - Tapping a row → **Session Detail**.
- **FAB:** bottom-right, 52×52, radius 6px, `--accent` fill, `--accent-ink` "+" glyph (26px/300),
  shadow `0 8px 22px -6px var(--accent)`. Opens New Session (not yet designed — see Backlog).
- **Sample data (name · path · status · age):**
  - taskmaster · `F:\rts\cc\taskmaster` · running · 3m
  - wonkybox_mcp · `F:\rts\Wonkybox\wonkybox_mcp` · idle · 3m
  - worka-app-2 · `F:\rts\Worka-App-2` · idle · 13m
  - cd_new · `F:\rts\cc\cd_new` · running · 14m
  - rtmailer · `F:\rts\rtmailer` · idle · 14m
  - cc_hub · `F:\rts\cc_hub` · ended · 26m
  - cc_hub · `F:\rts\cc_hub` · idle · 29m
  - rtpages · `F:\rts\rtpages` · ended · 44m
  - cd_new · `F:\rts\cc\cd_new` · ended · 52m

### 2. Session Detail (event log)
- **Purpose:** review a session's chronological hook/event stream and send a new prompt.
- **Header:** back arrow `←` (30×30 tap target) · session name (16/700, ellipsis) · "Auto" label
  (11 `--dim`) · **Auto toggle** (36×20 track, radius 999px; ON = `--accent` track, knob at
  `translateX(16px)`; OFF = `--border` track, knob at 0; 16px white knob; 0.15s transition).
- **Sub-row:** status pill (idle, amber) + full path in mono `--dim` (ellipsis).
- **Event list (newest first):** each event is a **timeline row**:
  - Rail column: a 10×10 rounded (3px) marker in the tone color, then a 2px `--border`
    connector line filling downward.
  - Content: top line = event **type** (13/700, tone color) + timestamp (10 mono `--faint`,
    right). Then, if there's a payload, a **main line** (12px, in a `--surface` box, radius 4px,
    1px border, single-line ellipsis) showing the human-readable value, followed by the **raw
    JSON** (9.5 mono `--faint`, ellipsis). `Stop` events show muted mono `null` instead.
  - **Event tone colors:** `UserPromptSubmit` → `--accent`; `Notification` → `--st-warn`;
    `Stop` → `--dim`.
- **Jump-to-latest:** floating pill bottom-right above the composer — "↑ Newest", `--accent`
  fill, 11/700 `--accent-ink`, radius 999px. Smooth-scrolls the log to top (newest).
- **Composer (footer, replaces bottom nav):** 1px top border, `--surface`/nav background.
  A prompt input (placeholder "Prompt", radius 4px, `--surface`, 1px border) + a 38×38 send
  button (radius 6px, `--accent`, arrow icon in `--accent-ink`). Below, right-aligned counter
  "0/8000" (9.5 mono `--faint`).
- **Sample events (type · human text · raw · age):**
  - Stop · — · `null` · 48m
  - UserPromptSubmit · "Dockerfile:4  2 | WORKDIR /app  3 | COPY . ." · `{"prompt":"Dockerfile:4\n…"}` · 59m
  - Stop · — · `null` · 1h
  - UserPromptSubmit · "all done, what env vars should i set?" · `{"prompt":"all done, what env vars should i set?"}` · 1h
  - Notification · "Claude needs your input — session idle" · `{"notification_type":"idle_prompt","message":"Claude…"}` · 1h
  - Stop · — · `null` · 1h
  - UserPromptSubmit · "SQL Error [42704]: ERROR: role \"exporter\" does not exist" · `{"prompt":"SQL Error [42704]…"}` · 1h
  - Notification · "Claude needs your input — session idle" · `{"notification_type":"idle_prompt","message":"Claude…"}` · 1h
  - Stop · — · `null` · 1h

### 3. Chat
- **Purpose:** ask questions about running sessions in natural language.
- **Header:** title "Chat" (19/700) + subtitle "Ask about your running sessions" (12 `--dim`).
- **Messages:** vertical list, 10px gap, 14px horizontal padding. User bubbles right-aligned,
  `--accent` fill, `--accent-ink` text, radius 14px with a 4px bottom-right tail. Claude bubbles
  left-aligned, `--surface` fill, `--text`, 1px `--border`, radius 14px with 4px bottom-left tail.
  Max width 82%.
- **Composer (footer, above bottom nav):** input placeholder "Ask about a session…" + 38×38
  send button (same as Detail).
- **Sample transcript:**
  - user: "why did the taskmaster session stop?"
  - claude: "It hit a Stop event right after the migration finished — no errors logged. It is idle now, waiting on your next prompt."
  - user: "restart it and run the test suite"
  - claude: "Restarting taskmaster and queuing `npm test`. I will ping you here when it finishes."

### 4. Knowledge Base (KB)
- **Purpose:** browse/search saved notes and docs across projects.
- **Header:** title "Knowledge Base" (19/700) + subtitle "5 notes across your projects" (12 `--dim`).
  Search field below: radius 4px, `--surface`, 1px border, a magnifier glyph + placeholder
  "Search knowledge base" (12.5 `--faint`).
- **List:** cards (9px gap, 14px padding), each radius 4px, `--surface`, 1px `--border`:
  - Title (13.5/600) + a tag chip right-aligned (mono uppercase, `--surface2` bg, `--accent` text).
  - Snippet (11.5 `--dim`, one-line ellipsis).
  - "updated {age} ago" (9.5 mono `--faint`).
- **Sample notes (title · tag · updated):** Deploy runbook · ops · 2d; Env vars — wonkybox ·
  config · 5h; SQL role fix [42704] · fix · 1h; Docker base images · infra · 3d; Prompt library ·
  prompts · 1w.

### Bottom Navigation (Sessions / Chat / KB; hidden on Detail)
- 1px top border, `--surface` background, 3 equal-width items. Each: 21px line icon over a
  10/600 label. Active item = `--accent`; inactive = `--dim`.
- Icons: Sessions = three stacked bars; Chat = speech bubble; KB = open book (two pages).
- Status bar (top of every screen): clock left; signal bars + a **theme toggle** (☀ in dark →
  switch to light, ☾ in light) right. Toggle swaps the entire theme instantly.

## Interactions & Behavior
- **Row tap** → navigate to Session Detail. **Back arrow** → Sessions.
- **Bottom nav** → switch between Sessions / Chat / KB (Detail is a pushed screen, not a tab).
- **Theme toggle** (status bar) → flip dark ↔ light globally, instant.
- **Auto toggle** (Detail) → boolean; animates knob 0.15s.
- **Jump-to-latest** (Detail) → smooth scroll event log to top.
- **FAB** → intended to open a New Session flow (not yet designed).
- No real network/async in the prototype — everything is local mock state.

## State Management
- `screen`: `'sessions' | 'detail' | 'chat' | 'kb'` — current view; Detail carries the selected
  session (prototype hardcodes `wonkybox_mcp`; wire to the tapped session).
- `theme`: `'dark' | 'light'` — persist to device storage.
- `auto`: boolean per session (Auto-continue toggle).
- Data: `sessions[]`, `events[]` (per session), `chat[]`, `kb[]`. In production these come from
  the LAN relay — sessions and events stream/poll live; status and timestamps update over time.

## Assets
- **Fonts:** IBM Plex Sans + IBM Plex Mono (Google Fonts). Bundle or link.
- **Icons:** simple inline SVG line icons (nav bars/bubble/book, send arrow, search). Replace
  with the codebase's icon set at equivalent weights (~1.9 stroke).
- No raster images or brand assets used.

## Files
- `AppPhone.dc.html` — the reusable phone component (all four screens + logic). Set `variant="util"`
  for this design. This is the primary reference.
- `Session Monitor Redesign.dc.html` — parent that mounts terminal/clean/util side by side (context only).

## Backlog / not yet designed
New Session flow (FAB), the `⋮` overflow / session-actions sheet (stop/restart/delete), Settings,
KB note detail, and a notifications/activity feed. Ask the designer if you need these.
